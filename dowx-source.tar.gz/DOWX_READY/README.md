# DOWX — Android MVP

DOWX is a first real Android MVP for a global participation entertainment network.

## MVP loop
See challenge → Join → Guess/participate → Get result → Return.

## Current build
- Native Android app
- Package: `com.dowx.app`
- Version: 0.1.0
- Dark DOWX identity
- Challenge #0: WHAT DOES DOWX MEAN?
- Trending challenges
- Simple bottom navigation presentation
- Codemagic configuration for debug APK and release APK

## Build with Codemagic
Connect this repository to Codemagic and run the `android-debug` workflow first. The debug APK is exported as:

`app/build/outputs/apk/debug/app-debug.apk`

The first goal is a working installable APK. Release signing and Google Play distribution come after the MVP is tested.
