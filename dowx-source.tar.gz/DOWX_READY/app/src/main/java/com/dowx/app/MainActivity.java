package com.dowx.app;

import android.app.*;import android.os.*;import android.graphics.Color;import android.graphics.Typeface;import android.view.*;import android.widget.*;import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
  LinearLayout root;
  int white=Color.WHITE, muted=Color.rgb(165,165,170), bg=Color.rgb(5,5,7), card=Color.rgb(18,18,22), accent=Color.rgb(255,55,95);
  @Override public void onCreate(Bundle b){super.onCreate(b); showHome();}
  TextView tv(String s,float size,int c){ TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(c);t.setTypeface(Typeface.create("sans",Typeface.NORMAL));t.setPadding(0,6,0,6);return t; }
  GradientDrawable shape(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(r);return g;}
  Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(bg);b.setTextSize(14);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(shape(white,28));b.setPadding(18,2,18,2);return b;}
  void base(){ root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(22,28,22,18);root.setBackgroundColor(bg);setContentView(root); }
  void showHome(){base(); TextView logo=tv("DOWX",32,white);logo.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(logo,new LinearLayout.LayoutParams(-1,60));root.addView(tv("DESTROY THE OLD. CREATE X.",11,muted));
    root.addView(tv("Global participation starts here.",26,white),new LinearLayout.LayoutParams(-1,70));
    LinearLayout challenge=new LinearLayout(this);challenge.setOrientation(LinearLayout.VERTICAL);challenge.setPadding(22,20,22,20);challenge.setBackground(shape(card,24));
    TextView tag=tv("CHALLENGE #0",12,accent);tag.setTypeface(Typeface.DEFAULT,Typeface.BOLD);challenge.addView(tag);TextView q=tv("WHAT DOES DOWX MEAN?",24,white);q.setTypeface(Typeface.DEFAULT,Typeface.BOLD);challenge.addView(q);challenge.addView(tv("The name is the first challenge. Guess the meaning. Unlock the clue. Join the world.",14,muted));
    Button join=btn("JOIN THE CHALLENGE");challenge.addView(join,new LinearLayout.LayoutParams(-1,56));join.setOnClickListener(v->showChallenge());root.addView(challenge,new LinearLayout.LayoutParams(-1,230));
    root.addView(tv("TRENDING NOW",13,muted),new LinearLayout.LayoutParams(-1,55));
    String[] cs={"LIGHT UP THE SKY","ONE MINUTE SILENCE","GLOBAL LAUGH","WORLDWIDE DANCE"};for(String c:cs){TextView x=tv("●  "+c,16,white);x.setPadding(4,12,4,12);root.addView(x);}
    Space sp=new Space(this);root.addView(sp,new LinearLayout.LayoutParams(1,0,1));TextView nav=tv("HOME          LIVE          RANK          PROFILE",12,muted);nav.setGravity(Gravity.CENTER);root.addView(nav);
  }
  void showChallenge(){base();TextView back=tv("‹  BACK",14,muted);root.addView(back);back.setOnClickListener(v->showHome());TextView n=tv("CHALLENGE #0",13,accent);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(n);TextView q=tv("WHAT DOES\nDOWX MEAN?",34,white);q.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(q);root.addView(tv("D = ?     O = ?     W = ?     X = ?",18,white));root.addView(tv("Think beyond the obvious. The answer unlocks the identity of DOWX.",15,muted));
    EditText e=new EditText(this);e.setHint("Enter your guess");e.setTextColor(white);e.setHintTextColor(Color.DKGRAY);e.setSingleLine(true);e.setBackground(shape(card,18));e.setPadding(20,0,20,0);root.addView(e,new LinearLayout.LayoutParams(-1,58));Button b=btn("SUBMIT GUESS");root.addView(b,new LinearLayout.LayoutParams(-1,58));TextView result=tv("",16,white);root.addView(result);b.setOnClickListener(v->{String g=e.getText().toString().trim(); if(g.length()>0){result.setText("Guess received. Your score: 100 XP\n\nClue unlocked: X = the unknown.");}});
  }
}
